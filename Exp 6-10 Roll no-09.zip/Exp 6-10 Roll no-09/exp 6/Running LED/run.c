#include <LPC214X.H>
void delay(void);
int main(void)
{

// select the pin function as GPIO
PINSEL0 = 0x00000000;
PINSEL1 = 0x00000000;
PINSEL2 = 0x00000000;
// Set the port direction
// P0.4-P0.7, P0.22, P0.28, P0.30 P1.16 port pins output)
IODIR0 = 0x504000F0;
IODIR1 = 0x00010000;
while(1)
{

IOSET0 = 0x00000010;
delay();
IOCLR0 = 0x00000010;
IOSET0 = 0x00000020;
delay();
IOCLR0 = 0x00000020;
IOSET0 = 0x00000040;
delay();
IOCLR0 = 0x00000040;
IOSET0 = 0x00000080;
delay();
IOCLR0 = 0x00000080;
IOSET0 = 0x00400000;
delay();

IOCLR0 = 0x00400000;
IOSET0 = 0x10000000;
delay();
IOCLR0 = 0x10000000;
IOSET0 = 0x40000000;
delay();
IOCLR0 = 0x40000000;
IOSET1 = 0x00010000;
delay();
IOCLR1 = 0x00010000;

}

}
void delay(void)
{
int i;
for(i=0; i<=1000000;i++)
{};

}
