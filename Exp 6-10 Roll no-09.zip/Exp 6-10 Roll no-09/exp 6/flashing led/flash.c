//Gourav Kiran Bidkar
//Roll no-09
//Experiment no-06 Flashing LED using LPC214X


#include<LPC214X.H>
void delay(void);

int main(void)
{

// select the pin function as GPIO
PINSEL0 = 0x00000000;
PINSEL1 = 0x00000000;
PINSEL2 = 0x00000000;
// Set the port direction
// P0.4-P0.7, P0.22, P0.28, P0.30 P1.16 port pins output)
IODIR0 = 0x504000F0;
IODIR1 = 0x00010000;
while(1)
{

IOSET0 = 0x504000F0;
IOSET1 = 0x00010000;
delay();
IOCLR0 = 0x504000F0;
IOCLR1 = 0x00010000;
delay();
}

}
void delay(void)

{
int i;
for(i=0; i<=1000000;i++)
{};

}
