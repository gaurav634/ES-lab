	 #include <LPC214X.H>

	 void delay1(void);
	 void delay2(void);

	 int main(void)
	 {
	 int i;
	 //delay();
	 //select the pin function as GPIO
	 PINSEL0 = 00;
	 //set the port direction
	 IODIR0 |= 0x000000F0; 
	 while(1)
	 {
	 for(i =0; i<500; i++)
	 {
	 IOCLR0 = 0x00000010;
	 delay2();
	 IOSET0 = 0x00000010;
	 delay1();
	 }

	 for(i =0; i<300; i++)
	 {

     	 IOCLR0 = 0x00000010;
	     delay2();
	     IOSET0 = 0x00000010;
	     delay2();
	 }

	 for(i =0; i<100; i++)
	 {
	    IOCLR0 = 0x00000010;
	    delay2(); delay1();
	    IOSET0 = 0x00000010;
	    delay1(); delay2();
   	 }
	}
 }
  
  
  void delay1(void)
  {
  unsigned int s;
  for(s=20000;s>0;s--)
  {
      ;
   }
 }

	   void delay2(void)
  {
  unsigned int s;
  for(s=40000;s>0;s--)
  {
      ;
   }
 }
