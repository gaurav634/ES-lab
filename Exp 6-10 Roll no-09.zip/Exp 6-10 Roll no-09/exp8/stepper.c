#include <LPC214X.H>

void delay_1sec(void);

int main(void)
{
    PINSEL0 = 00;
	IODIR0 |= 0x000000F0;

//	IODIR0 |= 0x000000F0;

	while(1)
	{
	   IOCLR0 = 0x000000C0;
	   IOSET0 = 0x00000060;
	   delay_1sec();

	   IOCLR0 = 0x00000060;
	   IOSET0 = 0x00000030;
	   delay_1sec();

	   IOCLR0 = 0x00000030;
	   IOSET0 = 0x00000090;
	   delay_1sec();

	   IOCLR0 = 0x00000090;
	   IOSET0 = 0x000000C0;
	   delay_1sec();

	 }
}

void delay_1sec(void)
{
   unsigned int a, delay1, delay2;
   for(a=10; a>0; --a)
   {
       for(delay2 = 200; delay2 > 0; --delay2)
	   {   
	       for(delay1 = 250; delay1 > 0; --delay1) { }
		 }
    }
}
