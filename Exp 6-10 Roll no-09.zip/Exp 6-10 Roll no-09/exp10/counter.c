#include<LPC214X.H>
 void delay(void);

 int main(void) 
 {
     unsigned char i=0;
	//unsigned int temp;
	 PINSEL0 = 00;
	 IODIR0|=(0XF<<4);

     while(1)
	  {
	      for(i=0;i<16;i++)
		  {
		      IOPIN0 =(i<<4);
			  delay();
			}
			for(i=15;i>0;i--)
			{
			   IOPIN0 =(i<<4);
			   delay();
			   
			   }
         }
 }

  void delay(void)
 {
    unsigned int a,delay1,delay2;
	for(a=50;a>0;--a)
	{
	   for(delay2=200;delay2>0;--delay2)
	   {
	     for(delay1=250;delay1>0;--delay1){}
		 }
	  }	 
}

