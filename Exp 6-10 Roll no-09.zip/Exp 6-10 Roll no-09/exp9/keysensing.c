#include <LPC214X.H>

int main(void)
{

   PINSEL0 = 0X00000000;
   PINSEL1 = 0X00000000;
   PINSEL2 = 0X00000000;

   IODIR0 |= 0x000000F0;

   IODIR0 = IODIR0 & 0xFFFF7FF7;

   IODIR1 = IODIR1 | 0x02000000;

   IODIR0 = IODIR0 | 0x00001000;

while(1)
   {
       if(IOPIN0 & 0x00000008)
	   {
	      IOCLR0 = 0x00000010;
		  IOCLR1 = 0x02000000;
		}
		else
		{
		   IOSET0 = 0x00000010;
		   IOSET1 = 0x02000000;
		}

		if(IOPIN0 & 0x00008000)
	   {
	       IOCLR0 = 0x00000020;
		   IOCLR1 = 0x00001000;
		}
		else
		{
		   IOSET0 = 0x00000020;
		   IOSET1 = 0x00001000;
		}
	}
}
